
package seneca.summer2004;

public class May {


   public String toString() {

      return "May 2004";
   }
}