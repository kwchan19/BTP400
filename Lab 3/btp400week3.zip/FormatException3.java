
class FormatException3 {

	public static void main(String[] args) {

	    Employee z[];

		z = new Employee [100];

        System.out.println( z[0].toString() );
	}
}