
package seneca.summer2004;

public class August {


   public String toString() {

      return "August 2004";
   }
}